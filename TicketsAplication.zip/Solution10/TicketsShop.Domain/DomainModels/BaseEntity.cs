﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicketsShop.Domain
{
    public class BaseEntity
    {
        public Guid Id { get; set; }

    }
}
