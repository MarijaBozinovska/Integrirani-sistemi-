﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TicketsShop.Domain.Identity;

namespace TicketsShop.Domain

{
    public class ShoppingCart : BaseEntity
    {

        public string OwnerId { get; set; }

        public EShopApplicationUser Owner { get; set; }


        public virtual ICollection<TicketInShoppingCart> Tickets { get; set; }

        public ShoppingCart() { }
    }
}
