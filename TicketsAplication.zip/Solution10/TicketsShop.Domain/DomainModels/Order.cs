﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TicketsShop.Domain.Identity;

namespace TicketsShop.Domain
{
    public class Order : BaseEntity
    {
        public string UserId { get; set; }
        public EShopApplicationUser User { get; set; }

        public virtual ICollection<TicketInOrder> Tickets { get; set; }
    }
}
